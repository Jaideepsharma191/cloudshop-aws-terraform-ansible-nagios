const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Mock Data
const products = [
    { id: 1, name: 'Cloud Widget A', price: 19.99, description: 'High performance cloud widget.', image: 'https://via.placeholder.com/300x200?text=Widget+A' },
    { id: 2, name: 'Cloud Widget B', price: 29.99, description: 'Enterprise grade cloud widget.', image: 'https://via.placeholder.com/300x200?text=Widget+B' },
    { id: 3, name: 'Cloud Gadget X', price: 49.99, description: 'Next-gen cloud gadget.', image: 'https://via.placeholder.com/300x200?text=Gadget+X' },
    { id: 4, name: 'Serverless Tool', price: 9.99, description: 'Lightweight serverless tool.', image: 'https://via.placeholder.com/300x200?text=Serverless+Tool' },
];

let cart = [];

// Routes
app.get('/', (req, res) => {
    res.render('index', { products });
});

app.get('/product/:id', (req, res) => {
    const product = products.find(p => p.id === parseInt(req.params.id));
    if (!product) return res.status(404).send('Product not found');
    res.render('product', { product });
});

app.get('/cart', (req, res) => {
    const cartItems = cart.map(item => {
        const product = products.find(p => p.id === item.productId);
        return { ...product, quantity: item.quantity };
    });
    const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    res.render('cart', { cartItems, total });
});

app.post('/cart/add', (req, res) => {
    const { productId } = req.body;
    const existingItem = cart.find(item => item.productId === parseInt(productId));
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ productId: parseInt(productId), quantity: 1 });
    }
    res.redirect('/cart');
});

app.post('/checkout', (req, res) => {
    cart = []; // Clear cart
    res.render('checkout_success');
});

app.get('/health', (req, res) => {
    res.status(200).send('OK');
});

app.listen(port, () => {
    console.log(`CloudShop running on port ${port}`);
});
