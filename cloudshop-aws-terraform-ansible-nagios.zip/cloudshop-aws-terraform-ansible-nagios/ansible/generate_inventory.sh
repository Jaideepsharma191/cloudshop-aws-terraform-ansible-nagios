#!/bin/bash

# Navigate to terraform directory
cd ../terraform

# Get IPs
WEB_IP=$(terraform output -raw web_public_ip)
NAGIOS_IP=$(terraform output -raw nagios_public_ip)

# Navigate back to ansible directory
cd ../ansible

# Create inventory file
cat <<EOF > inventory.ini
[web]
$WEB_IP ansible_user=ubuntu ansible_ssh_private_key_file=~/.ssh/cloudshop-key

[nagios]
$NAGIOS_IP ansible_user=ubuntu ansible_ssh_private_key_file=~/.ssh/cloudshop-key
EOF

echo "Inventory generated successfully!"
cat inventory.ini
