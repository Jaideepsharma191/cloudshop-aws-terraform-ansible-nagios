variable "region" {
  description = "AWS Region"
  default     = "us-east-1"
}

variable "vpc_cidr" {
  description = "VPC CIDR"
  default     = "10.0.0.0/16"
}

variable "public_subnet_cidr" {
  description = "Public Subnet CIDR"
  default     = "10.0.1.0/24"
}

variable "instance_type" {
  description = "EC2 Instance Type"
  default     = "t2.micro"
}

variable "public_key" {
  description = "SSH Public Key"
  type        = string
  # User should provide this via -var or terraform.tfvars
  # For demo purposes, we can default to a dummy key or ask user to generate one
  default     = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC..." 
}
